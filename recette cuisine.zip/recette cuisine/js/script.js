const recettes = [
    { nom: "Spaghetti", cat: "plat", img: "images/spaghetti.jpg" },
    { nom: "Pizza", cat: "plat", img: "images/pizza.jpg" },
    { nom: "Gâteau Chocolat", cat: "dessert", img: "images/gateau.jpg" },
    { nom: "Lasagne", cat: "plat", img: "images/lasagne.jpg" },
    { nom: "Riz Cantonais", cat: "plat", img: "images/riz-cantonais.jpg" },
    { nom: "Poulet Rôti", cat: "plat", img: "images/poulet-roti.jpg" },
    { nom: "Couscous", cat: "plat", img: "images/couscous.jpg" },
    { nom: "Quiche Lorraine", cat: "plat", img: "images/quiche.jpg" },
    { nom: "Tarte aux Pommes", cat: "dessert", img: "images/tarte-pommes.jpg" },
    { nom: "Brownies", cat: "dessert", img: "images/brownies.jpg" },
    { nom: "Crêpes", cat: "dessert", img: "images/crepes.jpg" },
    { nom: "Salade Niçoise", cat: "plat", img: "images/salade-nicoise.jpg" },
    { nom: "Macarons", cat: "dessert", img: "images/macarons.jpg" },
    { nom: "Burger", cat: "plat", img: "images/burger.jpg" },
    { nom: "Sushi", cat: "plat", img: "images/sushi.jpg" },
    { nom: "Paella", cat: "plat", img: "images/paella.jpg" },
    { nom: "Ratatouille", cat: "plat", img: "images/ratatouille.jpg" },
    { nom: "Pasta Carbonara", cat: "plat", img: "images/pasta-carbonara.jpg" },
    { nom: "Chocolat Fondant", cat: "dessert", img: "images/chocolat-fondant.jpg" },
    { nom: "Tiramisu", cat: "dessert", img: "images/tiramisu.jpg" },
    { nom: "Jus fraise ", cat: "jus", img: "images/jusfraise.jpeg" },
    { nom: "Jus Banane", cat: "jus", img: "images/jusbanane.jpg" },
    { nom: "Jus Citron", cat: "jus", img: "images/juscitron.webp" },
    { nom: "Jus Orange", cat: "jus", img: "images/jusorange.jpg" },
    { nom: "Jus Pomme", cat: "jus", img: "images/juspomme.webp" }
    
];

function afficherRecettes() {
    const liste = document.getElementById("liste");
    liste.innerHTML = "";
    recettes.forEach(r => {
        const card = document.createElement("div");
        card.classList.add("card");
        card.dataset.cat = r.cat;
        card.innerHTML = `<img src="${r.img}" alt="${r.nom}"><h3>${r.nom}</h3>`;
        liste.appendChild(card);
    });
}

function filtrerRecettes() {
    const val = document.getElementById("search").value.toLowerCase();
    document.querySelectorAll(".card").forEach(c => {
        c.style.display = c.querySelector("h3").innerText.toLowerCase().includes(val) ? "block" : "none";
    });
}

function filtrerCategorie(cat) {
    document.querySelectorAll(".card").forEach(c => {
        c.style.display = (cat === "all" || c.dataset.cat === cat) ? "block" : "none";
    });
}

function ajouterRecette() {
    const nom = document.getElementById("nom").value;
    const cat = document.getElementById("categorie").value;
    const ingredients = document.getElementById("ingredients").value;

    if (!nom || !ingredients) {
        alert("Tous les champs sont obligatoires !");
        return;
    }

    recettes.push({ nom, cat, img: "images/default.jpg" });
    afficherRecettes();

    alert("Recette ajoutée !");
    document.getElementById("nom").value = "";
    document.getElementById("ingredients").value = "";
}

window.onload = afficherRecettes;
